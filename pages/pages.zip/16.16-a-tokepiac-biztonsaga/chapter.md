---
title: 'A tőkepiac biztonsága '
---

### 1. fejezet

# A tőkepiac biztonsága