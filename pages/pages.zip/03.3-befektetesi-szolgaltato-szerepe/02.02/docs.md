---
title: 'Befektetési szolgáltatások'
taxonomy:
    category:
        - docs
---

A befektetési szolgáltatók által végezhető tevékenységeket Magyarországon törvény szabályozza (2007. évi CXXXVIII. – Bszt.), amely keretein belül alapvetően az alábbi szolgáltatásokat nyújthatják az ügyfelek részére:

+ számlavezetés 
+ megbízás felvétele és továbbítása 
+ megbízás végrehajtása az ügyfél javára 
+ portfoliókezelés 
+ befektetési tanácsadás 
+ a fentiekhez kapcsolódó megnevezett kiegészítő szolgáltatások (pl. letétkezelés, devizakereskedelem) 