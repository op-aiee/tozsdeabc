---
title: 'A befektetési szolgáltató szerepe'
taxonomy:
    category:
        - docs
child_type: docs
---

### 3. fejezet

#A befektetési szolgáltató szerepe