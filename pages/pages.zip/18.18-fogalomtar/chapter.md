---
title: 'Fogalomtár '
---

### 11. fejezet

# Fogalomtár