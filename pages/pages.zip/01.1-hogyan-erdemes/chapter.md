---
title: 'Hogyan érdemes befektetni?'
taxonomy:
    category:
        - docs
child_type: docs
---

### 1. fejezet

# Hogyan érdemes befektetni? 

Befektetésink akár hosszú évekre is meghatározhatják a pénzügyi helyzetünket, így mielőtt rövidebb- vagy hosszabb távra elkötelezzük magunkat, érdemes tájékozódni a különböző befektetési lehetőségekről és saját képességeinkhez, kockázattűrésünkhöz mérten megválasztani a befektetéseinket. Az utóbbi években a tőzsdei, tőkepiaci befektetések is egyszerűbbé és népszerűbbé, valamint könnyen és olcsón elérhetővé váltak. Mielőtt azonban bármilyen befektetésre adnánk a fejünket, érdemes pár fontos dolgot végiggondolni, különösen ha tőkepiaci (tőzsdei) befektetésről van szó.
