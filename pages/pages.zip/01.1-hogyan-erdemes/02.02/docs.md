---
title: 'Mennyi pénzt tudok nélkülözni rövidebb és hosszabb időre?'
taxonomy:
    category:
        - docs
---

A tőkepiaci befektetést és a tőzsdézést akár százezer forinttal is el lehet kezdeni, de a legfontosabb szempont, hogy magánbefektetőként csak annyi pénzt fektessünk be, amire a napi megélhetéshez nincs szükségünk, és amely összeg időbeni korlátok nélkül áll rendelkezésére. Különösen igaz ez, ha rövid távú (éven belüli) spekulációs célú befektetésekben gondolkozunk, mert rövid távon a tőzsdei árak jelentősen ingadozhatnak és ez komoly kockázatot jelent. Fontos, hogy megtakarításaink, befektetéseink kapcsán ne csak a jelenleg rendelkezésre álló összegekre gondoljunk, hanem rendszeres jövedelmeinkből is lehetőségeinkhez mérten tegyünk félre, mert ezzel folyamatosan növelni tudjuk a megtakarított állományt.