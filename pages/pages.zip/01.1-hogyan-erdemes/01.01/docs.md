---
title: 'Mik a pénzügyi céljaim és azoknak megfelelően milyen futamidő(k)re szeretnék befektetni?'
taxonomy:
    category:
        - docs
---

Befektetés előtt alaposan át kell gondolni, hogy milyen pénzügyi célokat szeretnénk elérni. Ilyen lehet egy jövő évi nyaralástól elkezdve egy gépkocsi vagy lakás megvásárlása, de ilyen cél lehet akár egy biztonsági tartalék megképzése is a váratlan kiadások fedezésére. Egyszerre több célunk is lehet, amiktől függően más-más befektetési időtáv(ok)ban szükséges gondolkodnunk, ezekhez az időtávokhoz pedig más-más befektetések lehetnek megfelelőek számunkra.