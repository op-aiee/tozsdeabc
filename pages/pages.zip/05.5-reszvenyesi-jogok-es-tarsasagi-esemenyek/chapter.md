---
title: 'Részvényesi jogok és társasági események '
---

### 5. fejezet

# Részvényesi jogok és társasági események 