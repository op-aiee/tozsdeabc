---
title: 'Tőzsde a részvényeken túl '
---

### 8. fejezet

# Tőzsde a részvényeken túl

A tőzsdéről az embereknek elsősorban a részvénykereskedés jut eszébe és a vállalatok forrásbevonásának piacaként tekintenek rá. A Budapesti Értéktőzsde piacain széles termékpaletta biztosítja, hogy minden befektető megtalálja azt a terméket, mely leginkább követi megtakarítási céljait.