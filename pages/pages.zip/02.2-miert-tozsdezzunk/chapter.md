---
title: 'Miért tőzsdézzünk?'
taxonomy:
    category:
        - docs
child_type: docs
---

### 2. fejezet

#Miért tőzsdézzünk?
