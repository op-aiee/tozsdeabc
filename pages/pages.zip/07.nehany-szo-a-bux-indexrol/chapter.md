---
title: 'Néhány szó a BUX indexről '
---

### 7. fejezet

# Néhány szó a BUX indexről