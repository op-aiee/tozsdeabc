---
title: 'Értékpapír ügyletkötések adózási kérdései '
---

### 10. fejezet

# Értékpapír ügyletkötések adózási kérdései
