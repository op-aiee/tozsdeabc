---
title: 'A tőzsdei kereskedés menete '
taxonomy:
    category:
        - docs
child_type: docs
---

### 4. fejezet
# A tőzsdei megbízás